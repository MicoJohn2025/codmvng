#!/bin/bash

directory_path="/data/local/tmp/"
file_name="key.config"
mkdir -p "${directory_path}"
echo "xunRYphlaDEIfyvP" > "${directory_path}${file_name}"
chmod 777 "${directory_path}${file_name}"